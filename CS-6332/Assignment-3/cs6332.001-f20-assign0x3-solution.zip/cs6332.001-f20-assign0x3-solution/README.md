# Solution

Brief descriptions and illustrations here. 

