
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>

#include "macros.h"
#include "arm_context.h"

/* addresses of asm callout glue code */

extern void* retCallout;


int fib();
int main(int argc, char *argv[]);

/*********************************************************************
 *
 *  callout handler
 *
 *   These get called by asm glue routines.
 *
 *********************************************************************/

void
handleRetCallout(SaveRegs *regs)
{
   // NOT_IMPLEMENTED();
   printf("inside function call\n");
   printf("cpsr: %x\n", regs->CPSR);
   for (int i=0; i < 13; i++) {
    printf("r[%d]: %x\n", i, regs->r[i]);
   }
   printf("lr %x\n", regs->lr);
   printf("sp %x\n", regs->sp);
}

/*********************************************************************
 *
 *  StartProfiling, StopProfiling
 *
 *   Profiling hooks. This is your place to inspect and modify the profiled
 *   function.
 *
 *********************************************************************/

void
StartProfiling(void *func)
{
    int8_t *func_ptr;
    func_ptr = (int8_t *) func;

    /*
     * TODO: Add your instrumentation code here.
     */


    // code[0] = 0xc3;

    int32_t rel_addr;
    int8_t *call_target = (int8_t *) &retCallout;

    int32_t offset;
    offset =call_target - func_ptr;
    offset -= 8; // now PC is fetching two instructions later.
    offset /= 4; // word (two-bytes) aligned.

    printf("func at %p, call target at %p, offset %x \n", func, call_target, offset);
    uint8_t *_offset = (uint8_t *) &offset;
    printf("%x %x %x %x\n", _offset[0], _offset[1], _offset[2], _offset[3]);

    /* 
    if ((uint32_t)(func) > (uint32_t)(call_target)) {
        rel_addr = ((uint32_t)(func) + 5) - (uint32_t)(call_target);
    } else {
        rel_addr = (uint32_t)(call_target) - ((uint32_t)(func) + 5);
    }
    */

    // patch func to call call_target
    func_ptr[0] = _offset[0];
    func_ptr[1] = _offset[1];
    func_ptr[2] = _offset[2];
    func_ptr[3] = 0xea;

    printf("patching the function at %p to call relative address %p\n",
           func, offset);
}


int main(int argc, char *argv[])
{
   int value;
   char *end;

   if (argc != 2) {
      fprintf(stderr, "usage: %s <value>\n", argv[0]);
      exit(1);
   }

   value = strtol(argv[1], &end, 10);

   if (((errno == ERANGE) 
        && ((value == LONG_MAX) || (value == LONG_MIN)))
       || ((errno != 0) && (value == 0))) {
      perror("strtol");
      exit(1);
   }

   if (end == argv[1]) {
      fprintf(stderr, "error: %s is not an integer\n", argv[1]);
      exit(1);
   }

   if (*end != '\0') {
      fprintf(stderr, "error: junk at end of parameter: %s\n", end);
      exit(1);
   }

   StartProfiling(fib);

   __builtin___clear_cache(fib, fib + 4);

   value = fib(value);

   printf("%d\n", value);
   exit(0);
}

int fib(int i)
{
   if (i <= 1) {
      return 1;
   }
   return fib(i-1) + fib(i-2);
}
