# Submission form

Name: <Your Name>
NetID: <Your NetID>

## x86

### Part 1

* Input 

<input for part1>

* Hash

<hash from /home/assign0x2-p1/solve>

### Part 2

* Input

<input for part1>

* Hash

<hash from /home/assign0x2-p2/solve>

###  Part 3

* Input

<input for part1>

* Hash

<hash from /home/assign0x2-p3/solve>

## ARM 

### Part 1
* Input

<input for part1>

* Hash

<hash from /home/assign0x2-p1/solve>

###  Part 2


* Input

<input for part1>

* Hash

<hash from /home/assign0x2-p2/solve>

### Part 3

* Input

<input for part1>

* Hash

<hash from /home/assign0x2-p3/solve>


