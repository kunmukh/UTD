This is a warm-up problem!
Run ./part0x00 and see how it works!

