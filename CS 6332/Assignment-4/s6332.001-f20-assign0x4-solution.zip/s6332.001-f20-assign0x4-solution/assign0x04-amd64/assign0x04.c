#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>

#include "macros.h"
#include "ia32_context.h"
#include "ia32_disas.h"

/* addresses of asm callout glue code */

extern void *jccCallout;
extern void *jmpCallout;
extern void *callCallout;
extern void *retCallout;

extern uint32_t ia32DecodeTable[]; /* see below */

/* instrumentation target */

extern int user_prog(int);

void StartProfiling(void *func);

void StopProfiling(void);

void ia32Decode(uint8_t *ptr, IA32Instr *instr);

void *callTarget;

// Original contents of memory that we patch
uint8_t *patchedAddr;
uint8_t patchedOneByte; // first byte
uint32_t patchedfourBytes; // next 4 bytes

// Prototypes
void restoreInstr();

void patchNextCFlow(uint8_t *);


/*********************************************************************
 *
 *  callout handlers
 *
 *   These get called by asm glue routines.
 *
 *********************************************************************/

void
handleJccCallout(SaveRegs regs) {
    // NOT_IMPLEMENTED();
    restoreInstr();
    uint8_t *next_instr;

    // JG rel8: jump if ZF = 0 and SF = 0F
    if (patchedOneByte == 0x7F) {
        // Calculate the next instruction to execute using the lsB of
        // the original code which holds the operand of the jcc.

        if (BIT(regs.eflags, 6) == 0 && BIT(regs.eflags, 7) == 0) {
            next_instr = patchedAddr + 2 + (patchedfourBytes & 0xff);
        } else {
            next_instr = patchedAddr + 2;
        }

        patchNextCFlow(next_instr);
        regs.pc = next_instr;
    } else {
        NOT_IMPLEMENTED();
    }
}

void
handleJmpCallout(SaveRegs regs) {
    restoreInstr();

    uint8_t *next_instr;

    // Calculate the next instruction to execute using the lsB of
    // the original code which holds the operand of the jmp.
    if (patchedOneByte == 0xeb) { // JMP rel8
        next_instr = patchedAddr + 2 + (patchedfourBytes & 0xff);

        patchNextCFlow(next_instr);
        regs.pc = next_instr;
    } else {
        NOT_IMPLEMENTED();
    }
}

void
handleCallCallout(SaveRegs regs) {
    restoreInstr();
    // calculate absolute target based on original relative one
    callTarget = (void *) (patchedAddr + 5 + (int32_t)(patchedfourBytes));
    patchNextCFlow(callTarget);
}

void
handleRetCallout(SaveRegs regs) {
    // NOT_IMPLEMENTED();
//	printf("regs.pc: %p\nregs.retPC: %p\n", regs.pc, regs.retPC);
    restoreInstr();
    patchNextCFlow(regs.retPC);
}


/*
 * instr should describe what's at addr. It's passed in only so we don't waste
 * time recomputing it.
 */

void patchToCallout(uint8_t *addr, IA32Instr instr) {
    // Save original code so we can restore it later
    patchedAddr = addr;
    patchedOneByte = addr[0];
    patchedfourBytes = *(uint32_t * )(addr + 1);

    int64_t rel_addr = 0;
    void *call_target = NULL;
    char *inst_name = NULL;

    uint32_t optype = ia32DecodeTable[instr.opcode];
    if (optype & IA32_RET) {
        call_target = &retCallout;
        inst_name = "ret";
    } else if (optype & IA32_JCC) {
        call_target = &jccCallout;
        inst_name = "jcc";
    } else if (optype & IA32_JMP) {
        call_target = &jmpCallout;
        inst_name = "jmp";
    } else if (optype & IA32_CALL) {
        call_target = &callCallout;
        inst_name = "call";
    } else {
        NOT_IMPLEMENTED();
    }

    addr[0] = 0xe8; // call instr. -- relative near call
    rel_addr = (int64_t) call_target - (int64_t)(addr + 5);

    *(int32_t * )(addr + 1) = rel_addr;
}

/*
 * Restores the code last patched by patch_in_call_to_me. If that function
 * wasn't called, something bad will probably happen.
 */
void restoreInstr() {
    *patchedAddr = patchedOneByte;
    *(uint32_t * ) (patchedAddr + 1) = patchedfourBytes;
}

void patchNextCFlow(uint8_t *addr) {
    IA32Instr instr;

    while (1) {
        ia32Decode(addr, &instr);
        if (IA32_DECODE_TYPE(ia32DecodeTable[instr.opcode]) == IA32_CFLOW) {
            break;
        }
        addr += instr.len;
    }
    // If it's a call to StopProfiling, don't patch it.

    if (ia32DecodeTable[instr.opcode] & IA32_CALL) {
        void *call_target = (void *) (addr + 5 + *(int32_t *) (addr + 1));
        if (call_target == &StopProfiling) {
            printf("A call to StopProfiling -- no need for patching.\n");
            return;
        }
    }
    patchToCallout(addr, instr);
}


/*********************************************************************
 *
 *  ia32Decode
 *
 *   Decode an IA32 instruction.
 *
 *********************************************************************/

void
ia32Decode(uint8_t *ptr, IA32Instr *instr) {
    // TODO: part1
    // NOT_IMPLEMENTED();
    uint8_t *instr_start = ptr; // hang on to the original value of ptr so we
    // can easily get the length at the end


    while (IA32_DECODE_TYPE(ia32DecodeTable[*ptr]) == IA32_PREFIX) {
        // printf("Found prefix 0x%x \n", *ptr);
        ptr++;
        instr->len++;
    }

    // Parse opcode
    instr->opcode = *ptr++;
    if (instr->opcode == 0x0f) {
        instr->opcode = 0x100 | *(ptr++);
    }

    // Look up instruction type
    int optype = ia32DecodeTable[instr->opcode];

#ifdef __DEBUG__
   printf("opcode: %x, type %d \n", instr->opcode, optype);
#endif
    ASSERT(optype != IA32_notimpl);

    // Figure out ModRM and SIB operands
    if (optype & IA32_MODRM) {
        uint8_t modrm = *ptr++;
        instr->modRM = modrm;
        uint8_t mod = modrm >> 6;
        uint8_t reg_op = (modrm & 0x38) >> 3;
        uint8_t rm = modrm & 7;
#ifdef __DEBUG__
        printf("opcode: %x, mod: %d, rm: %d, reg_op: %d\n",
               instr->opcode, mod, rm, reg_op);
#endif
        if (rm == 4 && mod != 0b11) {
            uint8_t sib = *ptr++;
        }

        if (mod == 0b01) {
            uint8_t disp = *ptr++;
        } else if (mod == 0b10 || (mod == 0b00 && rm == 5)) {
            uint32_t disp = *((uint32_t * )(ptr));
            ptr += 4;
        }
    } else {
        instr->modRM = -1;
    }

    // Deal with immediate operands
    if (optype & IA32_IMM8) {
        instr->imm = *ptr++;
    } else if (optype & IA32_IMM32) {
        instr->imm = *((uint32_t * )(ptr));
        ptr += 4;
    } else {
        instr->imm = 0;
    }

    instr->len = ptr - instr_start;
}

/*********************************************************************
 *
 *  StartProfiling, StopProfiling
 *
 *   Profiling hooks. This is your place to inspect and modify the profiled
 *   function.
 *
 *********************************************************************/

void
StartProfiling(void *func) {
    patchNextCFlow(func);
}

void
StopProfiling(void) {
    restoreInstr();
}

int main(int argc, char *argv[]) {
    int value;
    char *end;

    char buf[16];

    if (argc != 1) {
        fprintf(stderr, "usage: %s\n", argv[0]);
        exit(1);
    }

    printf("input number: ");
    scanf("%15s", buf);

    value = strtol(buf, &end, 10);

    if (((errno == ERANGE)
         && ((value == LONG_MAX) || (value == LONG_MIN)))
        || ((errno != 0) && (value == 0))) {
        perror("strtol");
        exit(1);
    }

    if (end == buf) {
        fprintf(stderr, "error: %s is not an integer\n", buf);
        exit(1);
    }

    if (*end != '\0') {
        fprintf(stderr, "error: junk at end of parameter: %s\n", end);
        exit(1);
    }

    StartProfiling(user_prog);

    value = user_prog(value);

    StopProfiling();

    printf("%d\n", value);
    exit(0);
}

