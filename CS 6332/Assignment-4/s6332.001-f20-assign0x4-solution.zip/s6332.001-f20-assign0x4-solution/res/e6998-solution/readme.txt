Virtual Machines - Homework 1
Daniel Benamy
db2501@columbia.edu

My root directory has the part 4 program, which pretty much includes the work 
from the previous problems. The partN directories are copies of it as I got 
to the various parts. There are some odd and hackish things I did which are 
in the partN folders but I fixed up later. So if you're angry at something, 
see if it's in the final version before you take off all my points :-)

In the final code, I don't output the instructions as they're being 
decoded because I didn't think you wanted them there for part 4. If you do, 
you can change the DPRINTs in patch_next_branch_from() to printfs or enable
DPRINTs.

Assumptions:
* I use near calls and jumps when patching with the assumption that this will 
only be used to profile code in the same segment as the profiling code.
* I store the profiling data in an array of ints which is 200000 elements long 
and represents addresses relative to 0x80480d4. If a basic block is executed 
more than INT_MAX times, or an address being profiled is less than 0x80480d4 
or at least 0x80480d4 + 200000, the program will fail.

Test Runs:
db2501@athens:~/VirtualMachines/hw1$ ./hw1 0
Basic block starting at address 0x804871d ran 1 times.
Basic block starting at address 0x804872a ran 1 times.
Basic block starting at address 0x8048756 ran 1 times.
Basic block starting at address 0x80488c6 ran 1 times.
1
db2501@athens:~/VirtualMachines/hw1$ ./hw1 2
Basic block starting at address 0x804871d ran 3 times.
Basic block starting at address 0x804872a ran 2 times.
Basic block starting at address 0x8048733 ran 1 times.
Basic block starting at address 0x8048741 ran 1 times.
Basic block starting at address 0x8048751 ran 1 times.
Basic block starting at address 0x8048756 ran 2 times.
Basic block starting at address 0x80488c6 ran 1 times.
2
db2501@athens:~/VirtualMachines/hw1$ ./hw1 3
Basic block starting at address 0x804871d ran 5 times.
Basic block starting at address 0x804872a ran 3 times.
Basic block starting at address 0x8048733 ran 2 times.
Basic block starting at address 0x8048741 ran 2 times.
Basic block starting at address 0x8048751 ran 2 times.
Basic block starting at address 0x8048756 ran 3 times.
Basic block starting at address 0x80488c6 ran 1 times.
3
db2501@athens:~/VirtualMachines/hw1$ ./hw1 30
Basic block starting at address 0x804871d ran 2692537 times.
Basic block starting at address 0x804872a ran 1346269 times.
Basic block starting at address 0x8048733 ran 1346268 times.
Basic block starting at address 0x8048741 ran 1346268 times.
Basic block starting at address 0x8048751 ran 1346268 times.
Basic block starting at address 0x8048756 ran 1346269 times.
Basic block starting at address 0x80488c6 ran 1 times.
1346269

I also wrote a little python program to make it easier to see the results of 
profiling. Here's a sample run of the whole thing:

$ make
cc -g -m32 hw1.c hw1.S -static -Wl,-N -o hw1
objdump -S hw1 > hw1.dis

$ ./hw1 5 > prof.out

$ ./pretty_profile.py
    Usage: ./pretty_profile.py <disassembly file> <profiling data file>

    Prints out the disassemly of any functions which were profiled.
    The first instruction any basic block that was profiled will
    have the number of times it was executed to it's left.

$ ./pretty_profile.py hw1.dis prof.out
----------------------------------------------------------------------
     | *   This is the user program to be profiled.
     | *
     | *********************************************************************/
     |
     |int fib(int i)
     |{
   15| 8048718: 55                      push   %ebp
     | 8048719: 89 e5                   mov    %esp,%ebp
     | 804871b: 53                      push   %ebx
     | 804871c: 83 ec 08                sub    $0x8,%esp
     |   if (i <= 1) {
     | 804871f: 83 7d 08 01             cmpl   $0x1,0x8(%ebp)
     | 8048723: 7f 09                   jg     804872e <fib+0x16>
     |      return 1;
    8| 8048725: c7 45 f8 01 00 00 00    movl   $0x1,-0x8(%ebp)
     | 804872c: eb 23                   jmp    8048751 <fib+0x39>
     |   }
     |
     |   return fib(i-1) + fib(i-2);
    7| 804872e: 8b 45 08                mov    0x8(%ebp),%eax
     | 8048731: 83 e8 01                sub    $0x1,%eax
     | 8048734: 89 04 24                mov    %eax,(%esp)
     | 8048737: e8 dc ff ff ff          call   8048718 <fib>
    7| 804873c: 89 c3                   mov    %eax,%ebx
     | 804873e: 8b 45 08                mov    0x8(%ebp),%eax
     | 8048741: 83 e8 02                sub    $0x2,%eax
     | 8048744: 89 04 24                mov    %eax,(%esp)
     | 8048747: e8 cc ff ff ff          call   8048718 <fib>
    7| 804874c: 01 c3                   add    %eax,%ebx
     | 804874e: 89 5d f8                mov    %ebx,-0x8(%ebp)
    8| 8048751: 8b 45 f8                mov    -0x8(%ebp),%eax
     |}
     | 8048754: 83 c4 08                add    $0x8,%esp
     | 8048757: 5b                      pop    %ebx
     | 8048758: 5d                      pop    %ebp
     | 8048759: c3                      ret
     |
----------------------------------------------------------------------
     |
     |int main(int argc, char *argv[])
     |{
     | 804875a: 8d 4c 24 04             lea    0x4(%esp),%ecx
     | 804875e: 83 e4 f0                and    $0xfffffff0,%esp
     | 8048761: ff 71 fc                pushl  -0x4(%ecx)
     | 8048764: 55                      push   %ebp
     | 8048765: 89 e5                   mov    %esp,%ebp
     | 8048767: 51                      push   %ecx
     | 8048768: 83 ec 24                sub    $0x24,%esp
     | 804876b: 89 4d e8                mov    %ecx,-0x18(%ebp)
     |   int value;
     |   char *end;
     |   int i;
     |
     |   for (i = 0; i < 200000; ++i) {
     | 804876e: c7 45 f8 00 00 00 00    movl   $0x0,-0x8(%ebp)
     | 8048775: eb 12                   jmp    8048789 <main+0x2f>
     |            profile_data[i] = 0;
     | 8048777: 8b 45 f8                mov    -0x8(%ebp),%eax
     | 804877a: c7 04 85 00 df 0b 08    movl   $0x0,0x80bdf00(,%eax,4)
     | 8048781: 00 00 00 00
     |{
     |   int value;
     |   char *end;
     |   int i;
     |
     |   for (i = 0; i < 200000; ++i) {
     | 8048785: 83 45 f8 01             addl   $0x1,-0x8(%ebp)
     | 8048789: 81 7d f8 3f 0d 03 00    cmpl   $0x30d3f,-0x8(%ebp)
     | 8048790: 7e e5                   jle    8048777 <main+0x1d>
     |            profile_data[i] = 0;
     |   }
     |
     |   if (argc != 2) {
     | 8048792: 8b 45 e8                mov    -0x18(%ebp),%eax
     | 8048795: 83 38 02                cmpl   $0x2,(%eax)
     | 8048798: 74 2e                   je     80487c8 <main+0x6e>
     |      fprintf(stderr, "usage: %s <value>\n", argv[0]);
     | 804879a: 8b 55 e8                mov    -0x18(%ebp),%edx
     | 804879d: 8b 42 04                mov    0x4(%edx),%eax
     | 80487a0: 8b 00                   mov    (%eax),%eax
     | 80487a2: 8b 15 04 c3 0b 08       mov    0x80bc304,%edx
     | 80487a8: 89 44 24 08             mov    %eax,0x8(%esp)
     | 80487ac: c7 44 24 04 52 06 0a    movl   $0x80a0652,0x4(%esp)
     | 80487b3: 08
     | 80487b4: 89 14 24                mov    %edx,(%esp)
     | 80487b7: e8 34 5d 00 00          call   804e4f0 <__fprintf>
     |      exit(1);
     | 80487bc: c7 04 24 01 00 00 00    movl   $0x1,(%esp)
     | 80487c3: e8 78 4d 00 00          call   804d540 <exit>
     |   }
     |
     |   value = strtol(argv[1], &end, 10);
     | 80487c8: 8b 55 e8                mov    -0x18(%ebp),%edx
     | 80487cb: 8b 42 04                mov    0x4(%edx),%eax
     | 80487ce: 83 c0 04                add    $0x4,%eax
     | 80487d1: 8b 10                   mov    (%eax),%edx
     | 80487d3: c7 44 24 08 0a 00 00    movl   $0xa,0x8(%esp)
     | 80487da: 00
     | 80487db: 8d 45 f0                lea    -0x10(%ebp),%eax
     | 80487de: 89 44 24 04             mov    %eax,0x4(%esp)
     | 80487e2: 89 14 24                mov    %edx,(%esp)
     | 80487e5: e8 36 50 00 00          call   804d820 <strtol>
     | 80487ea: 89 45 f4                mov    %eax,-0xc(%ebp)
     |
     |   if (((errno == ERANGE)
     | 80487ed: e8 3e 08 00 00          call   8049030 <__errno_location>
     | 80487f2: 8b 00                   mov    (%eax),%eax
     | 80487f4: 83 f8 22                cmp    $0x22,%eax
     | 80487f7: 75 12                   jne    804880b <main+0xb1>
     | 80487f9: 81 7d f4 ff ff ff 7f    cmpl   $0x7fffffff,-0xc(%ebp)
     | 8048800: 74 1a                   je     804881c <main+0xc2>
     | 8048802: 81 7d f4 00 00 00 80    cmpl   $0x80000000,-0xc(%ebp)
     | 8048809: 74 11                   je     804881c <main+0xc2>
     | 804880b: e8 20 08 00 00          call   8049030 <__errno_location>
     | 8048810: 8b 00                   mov    (%eax),%eax
     | 8048812: 85 c0                   test   %eax,%eax
     | 8048814: 74 1e                   je     8048834 <main+0xda>
     | 8048816: 83 7d f4 00             cmpl   $0x0,-0xc(%ebp)
     | 804881a: 75 18                   jne    8048834 <main+0xda>
     |        && ((value == LONG_MAX) || (value == LONG_MIN)))
     |       || ((errno != 0) && (value == 0))) {
     |      perror("strtol");
     | 804881c: c7 04 24 65 06 0a 08    movl   $0x80a0665,(%esp)
     | 8048823: e8 c8 5d 00 00          call   804e5f0 <perror>
     |      exit(1);
     | 8048828: c7 04 24 01 00 00 00    movl   $0x1,(%esp)
     | 804882f: e8 0c 4d 00 00          call   804d540 <exit>
     |   }
     |
     |   if (end == argv[1]) {
     | 8048834: 8b 55 e8                mov    -0x18(%ebp),%edx
     | 8048837: 8b 42 04                mov    0x4(%edx),%eax
     | 804883a: 83 c0 04                add    $0x4,%eax
     | 804883d: 8b 10                   mov    (%eax),%edx
     | 804883f: 8b 45 f0                mov    -0x10(%ebp),%eax
     | 8048842: 39 c2                   cmp    %eax,%edx
     | 8048844: 75 31                   jne    8048877 <main+0x11d>
     |      fprintf(stderr, "error: %s is not an integer\n", argv[1]);
     | 8048846: 8b 55 e8                mov    -0x18(%ebp),%edx
     | 8048849: 8b 42 04                mov    0x4(%edx),%eax
     | 804884c: 83 c0 04                add    $0x4,%eax
     | 804884f: 8b 00                   mov    (%eax),%eax
     | 8048851: 8b 15 04 c3 0b 08       mov    0x80bc304,%edx
     | 8048857: 89 44 24 08             mov    %eax,0x8(%esp)
     | 804885b: c7 44 24 04 6c 06 0a    movl   $0x80a066c,0x4(%esp)
     | 8048862: 08
     | 8048863: 89 14 24                mov    %edx,(%esp)
     | 8048866: e8 85 5c 00 00          call   804e4f0 <__fprintf>
     |      exit(1);
     | 804886b: c7 04 24 01 00 00 00    movl   $0x1,(%esp)
     | 8048872: e8 c9 4c 00 00          call   804d540 <exit>
     |   }
     |
     |   if (*end != '\0') {
     | 8048877: 8b 45 f0                mov    -0x10(%ebp),%eax
     | 804887a: 0f b6 00                movzbl (%eax),%eax
     | 804887d: 84 c0                   test   %al,%al
     | 804887f: 74 29                   je     80488aa <main+0x150>
     |      fprintf(stderr, "error: junk at end of parameter: %s\n", end);
     | 8048881: 8b 45 f0                mov    -0x10(%ebp),%eax
     | 8048884: 8b 15 04 c3 0b 08       mov    0x80bc304,%edx
     | 804888a: 89 44 24 08             mov    %eax,0x8(%esp)
     | 804888e: c7 44 24 04 8c 06 0a    movl   $0x80a068c,0x4(%esp)
     | 8048895: 08
     | 8048896: 89 14 24                mov    %edx,(%esp)
     | 8048899: e8 52 5c 00 00          call   804e4f0 <__fprintf>
     |      exit(1);
     | 804889e: c7 04 24 01 00 00 00    movl   $0x1,(%esp)
     | 80488a5: e8 96 4c 00 00          call   804d540 <exit>
     |   }
     |
     |   StartProfiling(fib);
     | 80488aa: c7 04 24 18 87 04 08    movl   $0x8048718,(%esp)
     | 80488b1: e8 fc fd ff ff          call   80486b2 <StartProfiling>
     |
     |   value = fib(value);
     | 80488b6: 8b 45 f4                mov    -0xc(%ebp),%eax
     | 80488b9: 89 04 24                mov    %eax,(%esp)
     | 80488bc: e8 57 fe ff ff          call   8048718 <fib>
    1| 80488c1: 89 45 f4                mov    %eax,-0xc(%ebp)
     |
     |   StopProfiling();
     | 80488c4: e8 fc fd ff ff          call   80486c5 <StopProfiling>
     |
     |   printf("%d\n", value);
     | 80488c9: 8b 45 f4                mov    -0xc(%ebp),%eax
     | 80488cc: 89 44 24 04             mov    %eax,0x4(%esp)
     | 80488d0: c7 04 24 b1 06 0a 08    movl   $0x80a06b1,(%esp)
     | 80488d7: e8 44 5c 00 00          call   804e520 <_IO_printf>
     |   exit(0);
     | 80488dc: c7 04 24 00 00 00 00    movl   $0x0,(%esp)
     | 80488e3: e8 58 4c 00 00          call   804d540 <exit>
     |
----------------------------------------------------------------------
