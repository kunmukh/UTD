
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <assert.h>

#define ASSERT              assert
#define NOT_REACHED()       assert(0)
#define NOT_IMPLEMENTED()   assert(0)
//#define DPRINT              printf
#define DPRINT

#define BIT(_v, _b)         (((_v) >> (_b)) & 0x1)
#define BITS(_v, _l, _h)    (((uint32_t)(_v) << (31-(_h))) >> ((_l)+31-(_h)))

/*********************************************************************
 *
 *  ia32DecodeTable
 *
 *   The decode table is provided to save you typing. The actual table is
 *   defined at the bottom of the file due to its size. Each opcode has an
 *   entry in the table. 2 byte opcodes are encoded as 0x1XX. For example the
 *   opcode 0x0f 0x83 would be encoded as 0x183. See Figure 2.12b in the text
 *   for further explaination.
 *
 *********************************************************************/

#define IA32_DATA            0       // default
#define IA32_notimpl         1
#define IA32_PREFIX          2
#define IA32_2BYTE           3
#define IA32_CFLOW           4
#define IA32_DECODE_TYPE(_d) ((_d) & 0x000f)

/*
 *  The following defines add extra information on top of the decode type.
 */

#define IA32_MODRM           0x0010
#define IA32_IMM8            0x0020   // REL8 also
#define IA32_IMM32           0x0040   // REL32 also

#define IA32_RET             0x0100
#define IA32_JCC             0x0200
#define IA32_JMP             0x0400
#define IA32_CALL            0x0800

extern unsigned ia32DecodeTable[]; /* see below */

/*********************************************************************
 *
 *  IA32Instr
 *
 *   Decoded information about a single ia32 instruction.
 *
 *********************************************************************/
typedef struct {
   uint16_t  opcode;
   uint8_t   len;
   unsigned  modRM;
   uint32_t  imm;
   unsigned  type;
} IA32Instr;

/*********************************************************************
 *
 *  IA32SaveRegs
 *
 *   Program registers saved on a callout. These must be restored
 *   when we return to the program.
 *
 *     pc - this is the return address of the callout
 *     retPC - this is only valid if the callout replaced a RET 
 *             instruction. This will be the return PC the ret
 *             will jump to.
 *
 *********************************************************************/
typedef struct {
   uint32_t   eflags;
   uint32_t   edi;
   uint32_t   esi;
   uint32_t   ebp;
   uint32_t   esp;
   uint32_t   ebx;
   uint32_t   edx;
   uint32_t   ecx;
   uint32_t   eax;
   void      *pc;
   void      *retPC;
} IA32SaveRegs;

/* addresses of asm callout glue code */
extern void* jccCallout;
extern void* jmpCallout;
extern void* callCallout;
extern void* retCallout;
void *callTarget;

// Original contents of memory that we patch
uint8_t *patched_addr;
uint8_t patched_instr_0; // first byte
uint32_t patched_instr_1; // next 4 bytes

// Number of times an address was executed.
// The index is relative to 0x80480d4. Eg: 0x80480d6 is in profile_data[2].
int profile_data[200000];
#define BASE_ADDR 0x80480d4

// Prototypes
void restore_patched_instructions();
void patch_next_branch_from(uint8_t *);
void StopProfiling();

void 
ia32Decode(uint8_t *ptr, IA32Instr *instr)
{
	uint8_t *instr_start = ptr; // hang on to the original value of ptr so we
	                            // can get the length at the end
	while (IA32_DECODE_TYPE(ia32DecodeTable[*ptr]) == IA32_PREFIX) {
		DPRINT("Found prefix %h.\n", *ptr);
		ptr++;
	}

	// Parse opcode
	instr->opcode = *ptr;
	ptr++;
	if (instr->opcode == 0x0f) {
		instr->opcode = 0x100 | *(ptr++);
	}

	// Look up instruction type
	int type = ia32DecodeTable[instr->opcode];
	instr->type = type;
	ASSERT(type != IA32_notimpl);

	// Figure out ModRM and SIB operands
	if (type & IA32_MODRM) {
		uint8_t modrm = *ptr++;
		instr->modRM = modrm;
		uint8_t mod = modrm >> 6;
		uint8_t reg_op = (modrm & 0x38) >> 3;
		uint8_t rm = modrm & 7;
		DPRINT("opcode: %x, mod: %d, rm: %d, reg_op: %d\n", 
		       instr->opcode, mod, rm, reg_op);
		if (rm == 4 && mod != 3) {
			uint8_t sib = *ptr++;
		}
		if (mod == 1) {
			uint8_t disp = *ptr++;
		} else if (mod == 2 || (mod == 0 && rm == 5)) {
			uint32_t disp = *((uint32_t *)(ptr));
			ptr += 4;
		}
	} else {
		instr->modRM = -1;
	}

	// Deal with immediate operands
	if (type & IA32_IMM8) {
		instr->imm = *ptr++;
	} else if (type & IA32_IMM32) {
		instr->imm = *((uint32_t *)(ptr));
		ptr += 4;
	} else {
		instr->imm = 0;
	}

	instr->len = ptr - instr_start;
}


/*********************************************************************
 *
 *  callout handlers
 *
 *   These get called by asm glue routines.
 *
 *********************************************************************/

void
handleJccCallout(IA32SaveRegs regs)
{
	restore_patched_instructions();
	uint8_t *next_instr;
	if (patched_instr_0 == 0x7F) { // JG rel8: jump if ZF = 0 and SF = 0F
		if (BIT(regs.eflags, 6) == 0 && BIT(regs.eflags, 7) == 0) {
			// Calculate the next instruction to execute using the lsB of
			// the original code which holds the operand of the jcc.
			next_instr = patched_addr + 2 + (patched_instr_1 & 0xff);
		} else {
			next_instr = patched_addr + 2;
		}
		patch_next_branch_from(next_instr);
		regs.pc = next_instr;
	} else {
		NOT_IMPLEMENTED();
	}
}

void
handleJmpCallout(IA32SaveRegs regs)
{
	restore_patched_instructions();
	uint8_t *next_instr;
	if (patched_instr_0 == 0xeb) { // JMP rel8
		// Calculate the next instruction to execute using the lsB of
		// the original code which holds the operand of the jmp.
		next_instr = patched_addr + 2 + (patched_instr_1 & 0xff);
		patch_next_branch_from(next_instr);
		regs.pc = next_instr;
	} else {
		NOT_IMPLEMENTED();
	}	
}

void
handleCallCallout(IA32SaveRegs regs)
{
	restore_patched_instructions();
	// calculate absolute target based on original relative one
	callTarget = (void *)(patched_addr + 5 + (int32_t)(patched_instr_1));
	patch_next_branch_from(callTarget);
}

void
handleRetCallout(IA32SaveRegs regs)
{
	DPRINT("regs.pc: %p\nregs.retPC: %p\n", regs.pc, regs.retPC);
	restore_patched_instructions();
	patch_next_branch_from(regs.retPC);
}

/*
 * Patches the instruction that addr points to do call into the profiler code.
 * It must be a flow instruction.
 * instr should describe what's at addr. It's passed in only so we don't waste
 * time reparsing.
 */
void patch_in_call_to_me(uint8_t *addr, IA32Instr instr)
{
	// Save original code so we can restore it later
	patched_addr = addr;
	patched_instr_0 = addr[0];
	patched_instr_1 = *(uint32_t *)(addr + 1);

	int32_t rel_addr;
	void *call_target;
	char *inst_name;
	if (instr.type & IA32_RET) {
		call_target = &retCallout;
		inst_name = "ret";
	} else if (instr.type & IA32_JCC) {
		call_target = &jccCallout;
		inst_name = "jcc";
	} else if (instr.type & IA32_JMP) {
		call_target = &jmpCallout;
		inst_name = "jmp";
	} else if (instr.type & IA32_CALL) {
		call_target = &callCallout;
		inst_name = "call";
	} else {
		NOT_REACHED();
	}	
	addr[0] = 0xe8; // relative near call
	if ((uint32_t)(addr) > (uint32_t)(call_target)) {
		rel_addr = ((uint32_t)(addr) + 5) - (uint32_t)(call_target);
	} else {
		rel_addr = (uint32_t)(call_target) - ((uint32_t)(addr) + 5);
	}
	*(uint32_t *)(addr + 1) = rel_addr;
	DPRINT("patching %s instruction at %p to call relative address %p\n", 
	       inst_name, addr, rel_addr);
}

/*
 * Restores the code last patched by patch_in_call_to_me. If that function
 * wasn't called, something bad will happen.
 */
void restore_patched_instructions()
{
	*patched_addr = patched_instr_0;
	*(uint32_t *)(patched_addr + 1) = patched_instr_1;
}

/* 
 * Patches the first flow instruction found from addr on to call into the
 * profiler.
 */
void patch_next_branch_from(uint8_t *addr)
{
	IA32Instr instruction;
	
	profile_data[(int)(addr) - BASE_ADDR]++;
	
	instruction.type = IA32_notimpl; // so we go into loop
	while (1) {
		ia32Decode(addr, &instruction);
		DPRINT("address %p, opcode: %x, len: %d\n", 
		       addr, instruction.opcode, instruction.len);
		if (IA32_DECODE_TYPE(instruction.type) == IA32_CFLOW) {
			break;
		}
		addr += instruction.len;
	}
	// If it's a call to StopProfiling, don't patch it.
	if (instruction.type & IA32_CALL) {
		void *call_target = (void *)(addr + 5 + *(int32_t *)(addr + 1));
		if (call_target == &StopProfiling) {
			DPRINT("Encountered a call to StopProfiling. Not patching that.\n");
			return;
		}
	}
	patch_in_call_to_me(addr, instruction);
}

void
StartProfiling(void *func)
{
	patch_next_branch_from(func);	
}

void
StopProfiling(void)
{
	int i;
	for (i = 0; i < 200000; ++i) {
		if (profile_data[i] > 0) {
			printf("Basic block starting at address %p ran %d times.\n", BASE_ADDR + i, profile_data[i]);
		}
	}
}


/*
 * This is the user program to be profiled.
 */
int fib(int i)
{
   if (i <= 1) {
      return 1;
   }
   return fib(i-1) + fib(i-2);
}

int main(int argc, char *argv[])
{
   int value;
   char *end;
   int i;

   for (i = 0; i < 200000; ++i) {
   	  profile_data[i] = 0;
   }
   
   if (argc != 2) {
      fprintf(stderr, "usage: %s <value>\n", argv[0]);
      exit(1);
   }

   value = strtol(argv[1], &end, 10);

   if (((errno == ERANGE) 
        && ((value == LONG_MAX) || (value == LONG_MIN)))
       || ((errno != 0) && (value == 0))) {
      perror("strtol");
      exit(1);
   }

   if (end == argv[1]) {
      fprintf(stderr, "error: %s is not an integer\n", argv[1]);
      exit(1);
   }

   if (*end != '\0') {
      fprintf(stderr, "error: junk at end of parameter: %s\n", end);
      exit(1);
   }

   StartProfiling(fib);
   
   value = fib(value);
   
   StopProfiling();

   printf("%d\n", value);
   exit(0);
}

unsigned ia32DecodeTable[] = {
   IA32_MODRM,                  IA32_MODRM,         // 00
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           0,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           IA32_2BYTE,
   IA32_MODRM,                  IA32_MODRM,         // 10
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           0,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           0,
   IA32_MODRM,                  IA32_MODRM,         // 20
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   IA32_PREFIX,                 0,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           0,
   IA32_MODRM,                  IA32_MODRM,         // 30
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   IA32_PREFIX,                 0,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,   
   IA32_IMM8,                   IA32_IMM32,   
   0,                           0,
   0,                           0,                  // 40
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,                  // 50
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,                  // 60
   IA32_notimpl,                IA32_notimpl, 
   IA32_PREFIX,                 IA32_PREFIX,
   IA32_PREFIX,                 IA32_PREFIX,
   IA32_IMM32,                  IA32_MODRM | IA32_IMM32,
   IA32_IMM8,                   IA32_MODRM | IA32_IMM8,
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8, // 70
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_CFLOW | IA32_JCC | IA32_IMM8,  IA32_CFLOW | IA32_JCC | IA32_IMM8,
   IA32_MODRM | IA32_IMM8,      IA32_MODRM | IA32_IMM32,      // 80
   IA32_MODRM | IA32_IMM8,      IA32_MODRM | IA32_IMM8,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,
   IA32_MODRM,                  IA32_MODRM,
   0,                           0,                  // 90
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   0,                           0,
   IA32_notimpl,                IA32_notimpl,       // a0
   IA32_notimpl,                IA32_notimpl, 
   0,                           0,
   0,                           0,
   IA32_IMM8,                   IA32_IMM32,
   0,                           0,
   0,                           0,
   0,                           0,
   IA32_IMM8,                   IA32_IMM8,         // b0
   IA32_IMM8,                   IA32_IMM8,    
   IA32_IMM8,                   IA32_IMM8,    
   IA32_IMM8,                   IA32_IMM8,    
   IA32_IMM32,                  IA32_IMM32,    
   IA32_IMM32,                  IA32_IMM32,    
   IA32_IMM32,                  IA32_IMM32,    
   IA32_IMM32,                  IA32_IMM32,    
   IA32_MODRM | IA32_IMM8,      IA32_MODRM | IA32_IMM8,  // c0
   IA32_notimpl,                IA32_CFLOW | IA32_RET, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_MODRM | IA32_IMM8,      IA32_MODRM | IA32_IMM32,
   IA32_notimpl,                0, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // d0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // e0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_CFLOW | IA32_CALL | IA32_IMM32,      IA32_notimpl, 
   IA32_notimpl,                IA32_CFLOW | IA32_JMP | IA32_IMM8, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // f0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 100
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 110
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 120
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 130
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 140
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 150
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 160
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 170
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,// 180
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_CFLOW | IA32_JCC | IA32_IMM32, IA32_CFLOW | IA32_JCC | IA32_IMM32,
   IA32_notimpl,                IA32_notimpl,       // 190
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 1a0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 1b0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_MODRM,                  IA32_MODRM,
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_MODRM,                  IA32_MODRM,
   IA32_notimpl,                IA32_notimpl,       // 1c0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 1d0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 1e0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl,       // 1f0
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
   IA32_notimpl,                IA32_notimpl, 
};


