#!/usr/bin/env python

import sys

try:
    dis_file = sys.argv[1]
    prof_file = sys.argv[2]
except:
    print "    Usage: %s <disassembly file> <profiling data file>\n" % sys.argv[0]
    print "    Prints out the disassemly of any functions which were profiled."
    print "    The first instruction any basic block that was profiled will have"
    print "    the number of times it was executed to it's left."
    sys.exit(0)

def isint(i):
    try:
        int(i)
        return True
    except:
        return False

prof_data = {}
p = open(prof_file)
for line in p:
    if line.startswith('Basic'):
        chunks = line.split()
        prof_data[chunks[5].split('x')[1]] = chunks[7]
p.close()

#print prof_data

func_text = []
func_profiled = False

print "----------------------------------------------------------------------"
dis = open(dis_file)
for line in dis:
    if len(line) > 3 and isint(line[0]) and line[-2] == ':':
        if func_profiled:
            print "".join(func_text).strip('\n')
            print "----------------------------------------------------------------------"
        func_text = []
        func_profiled = False
        continue
    addr = line.strip().split(':')[0]
    if addr in prof_data.keys():
        func_text.append("%5s|%s" % (prof_data[addr], line))
        func_profiled = True
    else:
        func_text.append("     |" + line)
dis.close()
if func_profiled:
    print "".join(func_text).strip('\n')
    print "----------------------------------------------------------------------"
