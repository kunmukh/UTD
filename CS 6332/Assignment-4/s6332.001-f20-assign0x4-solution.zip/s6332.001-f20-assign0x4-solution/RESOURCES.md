# Resources

## Intel architecture 

## IA32 disassembly guide

## ARM architecture

https://heyrick.eu/armwiki/The_Status_register

![](/uploads/upload_df496b2aaf631534cf94ab37bba1d223.png)

[Other Builtins (Using the GNU Compiler Collection (GCC))]

[Other Builtins (Using the GNU Compiler Collection (GCC))]:https://gcc.gnu.org/onlinedocs/gcc/Other-Builtins.html

### ARM disassembly guide



---