//
// Created by Kangkook Jee on 10/15/20.
//

/*********************************************************************
 *
 *  fibonacci function.
 *
 *   This is the target program to be profiled.
 *
 *********************************************************************/

#include <stdio.h>
#include <stdint.h>

#define __FIB__

#if defined (__FIB__)
uint64_t user_prog(int i) __attribute__((alias("fib")));

#elif defined (__FIB2__)
uint64_t user_prog(int i) __attribute__((alias("fib2")));

#elif defined (__FIB3__)
uint64_t user_prog(int i) __attribute__((alias("fib3")));
#endif



/*
 * the original implementation, exponential complexity.
 */

uint64_t fib(uint32_t i)
{
    if (i <= 1) {
        return i;
    }

    return fib(i-1) + fib(i-2);
}

/*
 * dynamic programming 1 -- bottom-up.
 */


uint64_t fib2(uint32_t n)
{
  /* Declare an array to store Fibonacci numbers. */
  int f[n+2];   // 1 extra to handle case, n = 0
  int i;

  /* 0th and 1st number of the series are 0 and 1*/
  f[0] = 0;
  f[1] = 1;

  for (i = 2; i <= n; i++)
  {
      /* Add the previous 2 numbers in the series
         and store it */
      f[i] = f[i-1] + f[i-2];
  }

  return f[n];
}


/*
 * dynamic programming 2 -- top-down.
 */

uint64_t fib3(uint32_t n)
{
    int a = 0, b = 1, c, i;
    if( n == 0)
        return a;
    for(i = 2; i <= n; i++) {
       c = a + b;
       a = b;
       b = c;
    }
    return b;
}
