#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ia32_context.h"
#include "ia32_disas.h"
#include "macros.h"

/* addresses of asm callout glue code */

extern void *jccCallout;
extern void *jmpCallout;
extern void *callCallout;
extern void *retCallout;

extern uint32_t ia32DecodeTable[]; /* see below */

/* instrumentation target */
extern uint64_t user_prog(uint32_t);

void StartProfiling(void *func);
void StopProfiling(void);

void ia32Decode(uint8_t *ptr, IA32Instr *instr);

void *callTarget;

// Original contents of memory that we patch
uint8_t *bbStartAddr;
uint8_t *patchedAddr;
uint8_t patchedOneByte;    // first byte
uint32_t patchedFourBytes; // next 4 bytes

// For -- part 3
typedef struct {
  uint8_t *bbStart;
  uint8_t *bbEnd;
  uint32_t bbLen;
  uint32_t cnt;
} counter_t;

counter_t *counter;

// Prototypes
void patchToCallout(uint8_t *addr, IA32Instr instr);
void restoreInstr();
uint32_t patchNextCFlow(uint8_t *);
static uint8_t __addr2hash(uint8_t *addr);

/*********************************************************************
 *
 *  callout handlers
 *
 *   These get called by asm glue routines.
 *
 *********************************************************************/

#define CF 0
#define PF 2
#define AF 4

#define ZF 6
#define SF 7
#define TF 8
#define IF 9
#define DF 10
#define OF 11

#define NT 14

#define SHORT_BRANCH(XX)                                                       \
  do {                                                                         \
    next_instr = patchedAddr + 2;                                              \
    if (XX) {                                                                  \
      int8_t offset = patchedFourBytes & 0xff;                                 \
      next_instr += offset;                                                    \
    }                                                                          \
  } while (0)


// FIXME: not so clean way to hand-over opcode.
static uint32_t _opcode;

void handleJccCallout(SaveRegs regs) {
  // NOT_IMPLEMENTED();
  restoreInstr();

  // part 3
  uint8_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;

  uint8_t *next_instr;

  switch (_opcode) {
  case 0x70: // JO rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x71: // JNO rel8
    NOT_IMPLEMENTED();
    break;

  case 0x72: // JB rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x73: // JAE rel8:
    SHORT_BRANCH(BIT(regs.eflags, CF) == 0);
    break;

  case 0x74: // JE rel8:
    SHORT_BRANCH(BIT(regs.eflags, ZF) == 1);
    break;

  case 0x75: // JNE rel8
    SHORT_BRANCH(BIT(regs.eflags, ZF) == 0);
    break;

  case 0x76: // JBE rel8
    SHORT_BRANCH(BIT(regs.eflags, CF) == 1 || BIT(regs.eflags, ZF) == 1);
    break;

  case 0x77: // JA rel8
    SHORT_BRANCH(BIT(regs.eflags, CF) == 0 && BIT(regs.eflags, ZF) == 0);
    break;

  case 0x78: // JS rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x79: // JNS rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x7A: // JP rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x7B: // JNP rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x7C: // JL rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x7D: // JGE rel8:
    NOT_IMPLEMENTED();
    break;

  case 0x7E: // JLE rel8:
    SHORT_BRANCH(BIT(regs.eflags, ZF) == 1 ||
                 (BIT(regs.eflags, SF) != BIT(regs.eflags, OF)));

  case 0x7F: // JG rel8:
    NOT_IMPLEMENTED();
    break;

  default:
    // printf("%x\n", _opcode);
    NOT_IMPLEMENTED();
  }

  patchNextCFlow(next_instr);
  regs.pc = next_instr;
}

void handleJmpCallout(SaveRegs regs) {
  restoreInstr();

  // part 3
  uint8_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;

  uint8_t *next_instr;

  // Calculate the next instruction to execute using the lsB of
  // the original code which holds the operand of the jmp.
  if (patchedOneByte == 0xeb) { // JMP rel8
    int8_t offset = patchedFourBytes & 0xff;
    next_instr = patchedAddr + 2 + offset;

    patchNextCFlow(next_instr);
    regs.pc = next_instr;
 } else {
    NOT_IMPLEMENTED();
  }
}

void handleCallCallout(SaveRegs regs) {
  restoreInstr();

  // part 3
  uint8_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;

  // calculate absolute target based on original relative one
  callTarget = (void *)(patchedAddr + 5 + (int32_t) (patchedFourBytes));
  patchNextCFlow(callTarget);
}

void handleRetCallout(SaveRegs regs) {
  restoreInstr();
  // part 3
  uint8_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;

  patchNextCFlow(regs.retPC);
}

/*
 * instr should describe what's at addr. It's passed in only so we don't waste
 * time recomputing it.
 */

static void __patchToCallout(uint8_t *addr, IA32Instr instr) {
  // Save original code so we can restore it later
  patchedAddr = addr;
  patchedOneByte = addr[0];
  patchedFourBytes = *(uint32_t *)(addr + 1);

  int32_t rel_addr = 0;
  void *call_target = NULL;
  char *inst_name = NULL;

  int32_t optype = ia32DecodeTable[instr.opcode];

  // FIXME: updating global variable to be referred from handler routines.
  _opcode = instr.opcode;

  if (optype & IA32_RET) {
    call_target = &retCallout;
    inst_name = "ret";
  } else if (optype & IA32_JCC) {
    call_target = &jccCallout;
    inst_name = "jcc";
  } else if (optype & IA32_JMP) {
    call_target = &jmpCallout;
    inst_name = "jmp";
  } else if (optype & IA32_CALL) {
    call_target = &callCallout;
    inst_name = "call";
  } else {
    NOT_IMPLEMENTED();
  }

  addr[0] = 0xe8; // relative near call

  rel_addr = (int32_t) call_target - (int32_t)(addr + 5);
  *(int32_t *)(addr + 1) = rel_addr;
}

uint32_t patchNextCFlow(uint8_t *addr) {
  IA32Instr instr;
  uint32_t bbLen = 0;

  // part 3
  bbStartAddr = addr;

  while (1) {
    ia32Decode(addr, &instr);
    bbLen++;

    if (IA32_DECODE_TYPE(ia32DecodeTable[instr.opcode]) == IA32_CFLOW) {
      break;
    }
    addr += instr.len;
  }

  uint8_t key = __addr2hash(bbStartAddr);
  // first seen.
  if (counter[key].bbEnd == 0) {
    counter[key].bbStart = bbStartAddr;
    counter[key].bbEnd = addr;
    counter[key].bbLen = bbLen;
    counter[key].cnt = 0;
  }

  // Endgame: If it's a call to StopProfiling, don't patch it.
  if (ia32DecodeTable[instr.opcode] & IA32_CALL) {
    void *call_target = (void *)(addr + 5 + *(int32_t *)(addr + 1));
    if (call_target == &StopProfiling) {
      printf("A call to StopProfiling -- no need for patching.\n");
      counter[key].cnt++;
      return bbLen;
    }
  }
  __patchToCallout(addr, instr);
  return bbLen;
}

static uint8_t __addr2hash(uint8_t *addr) {
  uint8_t key = 0xff & (int32_t) addr;
  uint8_t collision = 0;

  do {
    if (counter[key].bbStart == 0 || counter[key].bbStart == addr) {
      return key;
    } else {
      key++;
      collision++;
    }

    if (collision && key == 0xff & (int32_t) addr) {
      // Wrapped-around the whole key space.
      ASSERT("NO AVAILABLE HASH KEYS" && 0);
    }
  } while (1);
}

/*
 * Restores the code last patched by patch_in_call_to_me. If that function
 * wasn't called, something bad will probably happen.
 */
void restoreInstr() {
  *patchedAddr = patchedOneByte;
  *(uint32_t *)(patchedAddr + 1) = patchedFourBytes;
}

/*********************************************************************
 *
 *  ia32Decode
 *
 *   Decode an IA32 instruction.
 *
 *********************************************************************/

void ia32Decode(uint8_t *ptr, IA32Instr *instr) {
  uint8_t *instr_start = ptr; // hang on to the original value of ptr so we
  // can easily get the length at the end

#ifdef __DEBUG__
  printf("addr: %p ", instr_start);
#endif

  while (IA32_DECODE_TYPE(ia32DecodeTable[*ptr]) == IA32_PREFIX) {
    // printf("Found prefix 0x%x \n", *ptr);
    ptr++;
    instr->len++;
  }

  // Parse opcode
  instr->opcode = *ptr++;
  if (instr->opcode == 0x0f) {
    instr->opcode = 0x100 | *(ptr++);
  }

  // Look up instruction type
  int optype = ia32DecodeTable[instr->opcode];

#ifdef __DEBUG__
  printf("opcode: %x, type %d \n", instr->opcode, optype);
#endif
  ASSERT(optype != IA32_notimpl);

  // Figure out ModRM and SIB operands
  if (optype & IA32_MODRM) {
    uint8_t modrm = *ptr++;
    instr->modRM = modrm;
    uint8_t mod = modrm >> 6;
    uint8_t reg_op = (modrm & 0x38) >> 3;
    uint8_t rm = modrm & 7;

    if (rm == 4 && mod != 0b11) {
      uint8_t sib = *ptr++;
    }

    if (mod == 0b01) {
      uint8_t disp = *ptr++;
    } else if (mod == 0b10 || (mod == 0b00 && rm == 5)) {
      uint32_t disp = *((uint32_t *)(ptr));
      ptr += 4;
    }
  } else {
    instr->modRM = -1;
  }

  // Deal with immediate operands
  if (optype & IA32_IMM8) {
    instr->imm = *ptr++;
  } else if (optype & IA32_IMM32) {
    instr->imm = *((uint32_t *)(ptr));
    ptr += 4;
  } else {
    instr->imm = 0;
  }

  instr->len = ptr - instr_start;
}

/*********************************************************************
 *
 *  StartProfiling, StopProfiling
 *
 *   Profiling hooks. This is your place to inspect and modify the profiled
 *   function.
 *
 *********************************************************************/

void StartProfiling(void *func) {
  // Part 1
  IA32Instr instr;
  void* addr = func;
  uint32_t optype;

  do {
    ia32Decode(addr, &instr);
    optype = ia32DecodeTable[instr.opcode];

    printf("addr %p, opcode: %x, len: %d, isCFlow: %s\n",
      addr, instr.opcode, instr.len,
      IA32_DECODE_TYPE(optype) & IA32_CFLOW  ? "true": "false");

    addr += instr.len;

  } while (! (optype & IA32_RET));

/*
  // Part3 -- initialize data sturctured, naive hashing.
  counter = (counter_t *)malloc(sizeof(counter_t) * 256);
  memset(counter, 0, sizeof(counter_t) * 256);

  // Part 2
  patchNextCFlow(func);
}

void StopProfiling(void) {
  restoreInstr();

  // Part 3 -- outputing stats.
  uint64_t total = 0;
  for (int i = 0; i < 256; i++) {
    if (counter[i].bbEnd) {
      printf("Start: %p, End: %p, size: %d, count: %d\n", counter[i].bbStart,
             counter[i].bbEnd, counter[i].bbLen, counter[i].cnt);
      total += counter[i].bbLen * counter[i].cnt;
    }
*/
}

void
StopProfiling(void) {
    // restoreInstr();
}

int main(int argc, char *argv[]) {
  uint64_t value;
  char *end;

  char buf[16];

  if (!(argc == 1 || argc == 2)) {
    fprintf(stderr, "usage: %s [num]\n", argv[0]);
    exit(1);
  }

  if (argc == 1) {
    printf("input number: ");
    scanf("%15s", buf);
  } else if (argc == 2) {
    strncpy(buf, argv[1], 16);
  }

  value = strtol(buf, &end, 10);

  if (((errno == ERANGE) && ((value == LONG_MAX) || (value == LONG_MIN))) ||
      ((errno != 0) && (value == 0))) {
    perror("strtol");
    exit(1);
  }

  if (end == buf) {
    fprintf(stderr, "error: %s is not an integer\n", buf);
    exit(1);
  }

  if (*end != '\0') {
    fprintf(stderr, "error: junk at end of parameter: %s\n", end);
    exit(1);
  }

  StartProfiling(user_prog);

  value = user_prog(value);

  StopProfiling();

  printf("%llu\n", value);
  exit(0);
}
