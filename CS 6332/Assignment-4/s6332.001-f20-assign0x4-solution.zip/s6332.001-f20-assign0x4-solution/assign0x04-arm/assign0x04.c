#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "arm_context.h"
#include "arm_disas.h"
#include "macros.h"


/*
 * define macro to toggle different parts.
 */

#define __PART__ 3

/* addresses of asm callout glue code */
extern void *blCallout;
extern void *bCallout;
extern void *bxCallout;
extern void *bgtCallout;
void *callTarget;

extern int user_prog(int);

void StartProfiling(void *func);

void StopProfiling(void);

void armDecode(uint8_t *ptr, ARMInstr *instr);

void *callTarget;

// Original contents of memory that we patch
#if __PART__  >= 3
uint8_t *bbStartAddr;
#endif

uint8_t *patchedAddr;
uint32_t patchedFourBytes; // 4 bytes

#if __PART__  >= 3
// For -- part 3
typedef struct {
  uint8_t *bbStart;
  uint8_t *bbEnd;
  uint32_t bbLen;
  uint32_t cnt;
} counter_t;

counter_t *counter;
#endif

// Prototypes
void __patchToCallout(uint8_t *addr, ARMInstr instr);
void restoreInstr();
uint32_t patchNextCFlow(uint8_t *);
static uint8_t __addr2hash(uint8_t *addr);

/*********************************************************************
 *
 *  callout handlers
 *
 *   These get called by asm glue routines.
 *
 *********************************************************************/
void handleBCallout(SaveRegs *regs) {
  restoreInstr();

  // part 3
  #if __PART__  >= 3
  int32_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;
  #endif

  uint8_t *nextInst = 0;
  nextInst = patchedAddr + 8; // due to ARM pipeline.
  int32_t offset = 0x00ffffff & patchedFourBytes;

  // negative value in 2's complement encoding.
  if (BIT(offset, 23)) {
    offset |= 0xff000000;
  }

  offset <<= 2; // 4 bytes align.
  nextInst += offset;

  regs->retPC = nextInst;
  patchNextCFlow(nextInst);
}

void handleBgtCallout(SaveRegs *regs) {
  restoreInstr();

  // part 3
  #if __PART__  >= 3
  int32_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;
  #endif

  uint8_t *nextInst = 0;

#define _Z 30
#define _N 31
#define _V 28

  // Taken:  [Reason: !Z && N==V]
  if (!BIT(regs->CPSR, _Z) && (BIT(regs->CPSR, _N) == BIT(regs->CPSR, _V))) {
    // branch to the target.
    nextInst = patchedAddr + 8; // due to ARM pipeline.
    int32_t offset = 0x00ffffff & patchedFourBytes;

    // negative value in 2's complement encoding.
    if (BIT(offset, 23)) {
      offset |= 0xff000000;
    }

    offset <<= 2; // 4 bytes align, X4
    nextInst += offset;
  }
  // fallthrough to next instruction.
  else {
    nextInst = patchedAddr + 4;
  }

  regs->retPC = nextInst;
  patchNextCFlow(nextInst);
}

// `bl` is virtually a `call` instruction
void handleBlCallout(SaveRegs *regs) {

  restoreInstr();

  // part 3
  #if __PART__  >= 3
  int32_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;
  #endif

  uint8_t *nextInst = 0;
  nextInst = patchedAddr + 8; // due to ARM pipeline.
  int32_t offset = 0x00ffffff & patchedFourBytes;

  // negative value in 2's complement encoding.
  if (BIT(offset, 23)) {
    offset |= 0xff000000;
  }

  offset <<= 2; // 4 bytes align.
  nextInst += offset;

  regs->retPC = nextInst;

  if (nextInst != (uint8_t *)&StopProfiling)
    patchNextCFlow(nextInst);
}

void handleBxCallout(SaveRegs *regs) {

  restoreInstr();

  // part 3
  #if __PART__  >= 3
  int32_t key = __addr2hash(bbStartAddr);
  counter[key].cnt += 1;
  #endif

  uint8_t *nextInst = 0;
  nextInst = (uint8_t *)regs->lr;

  patchNextCFlow(nextInst);
}

void __patchToCallout(uint8_t *addr, ARMInstr instr) {
  // Save original code so we can restore it later
  patchedAddr = addr;
  patchedFourBytes = *(uint32_t *)(addr);

  void *call_target = NULL;
  char *inst_name = NULL;

  uint8_t br = 0;

  if (IS_ARM_BL(instr.opcode)) {
    inst_name = "BL";
    call_target = &blCallout;
    br = ARM_BL;

  } else if (IS_ARM_BX(instr.opcode)) {
    inst_name = "BX";
    call_target = &bxCallout;
    br = ARM_B;

  } else if (IS_ARM_B(instr.opcode)) {
    if (instr.cond == ARM_COND_GT) { // Greater than
      inst_name = "BGT";
      call_target = &bgtCallout;
      br = ARM_B;

    } else if (instr.cond == ARM_COND_AL) { // always
      inst_name = "B";
      call_target = &bCallout;
      br = ARM_B;

    } else {
      // we are only covering instructions from
      // fib()
      NOT_IMPLEMENTED();
    }
  } else {
    // we are only covering instructions fromn
    // fib()
    NOT_IMPLEMENTED();
  }

  // offset calculation and little endian encoding.

  int32_t offset = (int32_t)call_target - (int32_t)(addr + 8);
  offset >>= 2; // word (two-bytes) aligned

  uint8_t *_offset = (uint8_t *)&offset;

  addr[0] = _offset[0];
  addr[1] = _offset[1];
  addr[2] = _offset[2];
  addr[3] = br; // Branch instr.
  __builtin___clear_cache((void *)addr, (void *)(addr + 4));
}

/*
 * Restores the code last patched by patch_in_call_to_me. If that function
 * wasn't called, something bad will probably happen.
 */
void restoreInstr() {
  uint32_t *__patchedAddr = (uint32_t *)patchedAddr;
  *__patchedAddr = patchedFourBytes;

  __builtin___clear_cache((void *)patchedAddr, (void *)(patchedAddr + 8));
}

uint32_t patchNextCFlow(uint8_t *addr) {
  ARMInstr instr;
  uint32_t bbLen = 0;

#if __PART__  >= 3
  // part 3
  bbStartAddr = addr;
#endif

  while (1) {
    armDecode(addr, &instr);
    bbLen++;
    if (IS_ARM_CFLOW(instr.opcode)) {
      break;
    }
    addr += instr.len;
  }
#if __PART__  >= 3
   uint8_t key = __addr2hash(bbStartAddr);
  // first seen.
  if (counter[key].bbEnd == 0) {
    counter[key].bbStart = bbStartAddr;
    counter[key].bbEnd = addr;
    counter[key].bbLen = bbLen;
    counter[key].cnt = 0;
  }
#endif

  __patchToCallout(addr, instr);
  return bbLen;
}

#if __PART__  >= 3
static uint8_t __addr2hash(uint8_t *addr) {
  uint8_t key = 0xff & (int32_t) addr;
  uint8_t collision = 0;

  do {
    if (counter[key].bbStart == 0 || counter[key].bbStart == addr) {
      return key;
    } else {
      key++;
      collision++;
    }

    if (collision && key == 0xff & (int32_t) addr) {
      // Wrapped-around the whole key space.
      ASSERT("NO AVAILABLE HASH KEYS" && 0);
    }
  } while (1);
}
#endif

/*********************************************************************
 *
 *  arm32Decode
 *
 *   Decode an ARM instruction.
 *
 *********************************************************************/

void armDecode(uint8_t *ptr, ARMInstr *instr) {
  // NOT_IMPLEMENTED();
  int32_t inst = *((uint32_t *)ptr);
  // 2nd and 3rd bytes after condition prefix
  instr->cond = (uint8_t)BITS(inst, 28, 31);   // 4-bits
  instr->opcode = (uint8_t)BITS(inst, 20, 27); // 8-bits
  instr->len = 4;
}

/*********************************************************************
 *
 *  StartProfiling, StopProfiling
 *
 *   Profiling hooks. This is your place to inspect and modify the profiled
 *   function.
 *
 *********************************************************************/

void StartProfiling(void *func) {
#if __PART__  >= 3    
  // Part3 -- initialize data sturctured, naive hashing.
  counter = (counter_t *)malloc(sizeof(counter_t) * 256);
  memset(counter, 0, sizeof(counter_t) * 256);
#endif

  // part2
#if __PART__  >= 2
  patchNextCFlow(func);
#elif __PART__ == 1
  ARMInstr instr;
  int8_t* addr = func;
  do {
    armDecode(addr, &instr);
    printf("addr %p, opcode: %x, len: %d, isCFlow: %s\n", 
     addr, instr.opcode, instr.len, IS_ARM_CFLOW(instr.opcode) ? "true": "false");
    addr += instr.len;
  } while (!IS_ARM_BX(instr.opcode));
#endif
}

void StopProfiling(void) {

#if __PART__  >= 2
  restoreInstr();
#endif

#if __PART__  >= 3
  // Part 3 -- outputing stats.
  uint64_t total = 0;
  for (int i = 0; i < 256; i++) {
    if (counter[i].bbEnd) {
      printf("Start: %p, End: %p, size: %d, count: %d\n", counter[i].bbStart,
             counter[i].bbEnd, counter[i].bbLen, counter[i].cnt);
      total += counter[i].bbLen * counter[i].cnt;
    }
  }

  printf("Total: %llu\n", total);
  free(counter);
#endif
}

int main(int argc, char *argv[]) {
  int value;
  char *end;

  char buf[16];

  if (argc != 1) {
    fprintf(stderr, "usage: %s\n", argv[0]);
    exit(1);
  }

  printf("input number: ");
  scanf("%15s", buf);

  value = strtol(buf, &end, 10);

  if (((errno == ERANGE) && ((value == LONG_MAX) || (value == LONG_MIN))) ||
      ((errno != 0) && (value == 0))) {
    perror("strtol");
    exit(1);
  }

  if (end == buf) {
    fprintf(stderr, "error: %s is not an integer\n", buf);
    exit(1);
  }

  if (*end != '\0') {
    fprintf(stderr, "error: junk at end of parameter: %s\n", end);
    exit(1);
  }

  StartProfiling(user_prog);

  value = user_prog(value);

  StopProfiling();

  printf("%d\n", value);
  exit(0);
}
