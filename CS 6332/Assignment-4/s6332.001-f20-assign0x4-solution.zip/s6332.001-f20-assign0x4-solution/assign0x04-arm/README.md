## Instruction decoding

* Chapter 5 from ARM® Architecture Reference Manual (ARMv7-A and ARMv7-R edition)
